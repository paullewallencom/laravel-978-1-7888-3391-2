<div class="container">
    <div class="content">
        <div class="title">Hi i'm a view</div>
    </div>
</div>