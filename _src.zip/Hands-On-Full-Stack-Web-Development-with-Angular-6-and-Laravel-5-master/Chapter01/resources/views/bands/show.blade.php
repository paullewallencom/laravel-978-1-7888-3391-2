<h1>Band {{ $band->id }}</h1>
<ul>
    <li>band: {{ $band->name }}</li>
    <li>description: {{ $band->description }}</li>
</ul>