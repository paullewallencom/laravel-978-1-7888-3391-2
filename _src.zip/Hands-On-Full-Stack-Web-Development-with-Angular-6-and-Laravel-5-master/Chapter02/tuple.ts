const organizedArray: [number, string, boolean] = [0, 'text', false];
let myArray: [number, string, boolean];
myArray = [0, 'text', false]
console.log(myArray);