var organizedArray = [0, 'text',
    false];
var myArray;
myArray = [0, 'text', false];
console.log(myArray);
