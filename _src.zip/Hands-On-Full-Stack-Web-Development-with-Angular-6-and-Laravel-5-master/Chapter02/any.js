var band;
band = {
    name: "Motorhead",
    description: "Heavy metal band",
    rate: 10
};
console.log(band);
band = "Motorhead";
console.log(band);
