console.log('TypeScript Working...');

function addOne (i: number): number { return i + 1 }
addOne(1)
