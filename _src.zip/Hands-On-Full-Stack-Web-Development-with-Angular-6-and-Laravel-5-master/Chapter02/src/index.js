"use strict";
console.log('TypeScript Working...');
function addOne(i) { return i + 1; }
addOne(1);
