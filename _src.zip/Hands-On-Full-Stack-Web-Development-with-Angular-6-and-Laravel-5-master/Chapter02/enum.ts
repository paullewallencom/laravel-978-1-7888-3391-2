enum bands {
    Motorhead,
    Metallica,
    Slayer
}
console.log(bands);

let myFavoriteBand = bands.Slayer;
console.log(myFavoriteBand);
